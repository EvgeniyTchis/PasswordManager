{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE OverloadedStrings #-}
module Main where

import Lib
import GHC.Generics
import Data.Aeson

data Entry = Entry 
    { name     :: String
    , username :: String
    , password :: String
    } deriving (Generic, Show)

instance ToJSON Entry where
    toEncoding = genericToEncoding defaultOptions

instance FromJSON Entry

main :: IO ()
main = putStrLn "Hello World!"