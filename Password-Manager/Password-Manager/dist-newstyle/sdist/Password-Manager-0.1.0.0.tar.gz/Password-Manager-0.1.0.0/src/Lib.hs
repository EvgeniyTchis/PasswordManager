module Lib
    ( someFunc
    ) where
        
import Data.Aeson
import Data.Aeson.TH
import GHC.Generics

someFunc :: IO ()
someFunc = putStrLn "someFunc"
